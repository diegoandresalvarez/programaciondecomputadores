#ifndef CAMARA_H
#define CAMARA_H

#include "vector3.h"

// *** *** se definen las variables globales *** ***
extern double scaling_factor;
extern double inc_scaling_factor;

// (xcen,ycen) son las coordenadas del punto central de la pantalla;
extern int xcen, ycen;

// N y E son los vectores unitario que definen el plano de proyeccion
// V es el vector unitario normal al plano de proyeccion
extern vector3 E, N, V;

// "eye" en la proteccion central representa la posicion del OJO observador
extern vector3 eye;



// *** *** se definen las estructuras *** ***
typedef struct
{
    int  x, y;
} punto2D;




// *** *** se definen los prototipos de funciones *** ***
vector3 rot_x_en_u(vector3 x, vector3 u, double w);
vector3 proy_normal(vector3 x);
vector3 proy_central(vector3 x);
punto2D plano_a_pantalla(vector3 pun);
inline vector3 recalc_N(void);
inline vector3 recalc_E(void);
#endif
