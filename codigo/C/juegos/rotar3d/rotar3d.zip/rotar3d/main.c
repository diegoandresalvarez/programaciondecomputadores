//PROGRAMA VISUALIZADOR DE OBJETOS 3D
// Elaborador por Diego Andres Alvarez Marín (diegoandresalvarez@gmx.net)
// El programa muestra el objeto con una vista en perspectiva
// Utilice las flechas para mover el objeto
//  + para alejar la c mara (haciendo una proyeccion mas ortogonal
//  - para alejar la camara (haciendo una proyeccion mas en perspectiva
// < y > para hacer zoom
// Home para volver al estado inicial
// Ctrl+ flecha izq y Ctrl + flecha der para girar el objeto
// alrededor del plano normal a la pantalla

#pragma GCC diagnostic ignored "-Wswitch"

// COMPILE CON:
// WINDOWS:
//
//
// LINUX:
// gcc -Wall main.c camara.c objeto.c vector3.c -lm -lSDL -lSDL_gfx

#include <SDL/SDL.h>
#include <SDL/SDL_gfxPrimitives.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "vector3.h"
#include "camara.h"
#include "objeto.h"

// Se definen las constantes
int maxx, maxy;
const double ang = 0.1;
const int SCREEN_WIDTH = 640;         // Los atributos de la pantalla
const int SCREEN_HEIGHT = 480;
const int SCREEN_BPP = 32;
SDL_Surface *screen = NULL;           // La superficie (el lienzo)
SDL_Event event;                      // La estructura event

// Prototipos de funciones
bool inicializar_modo_grafico(void);
void clean_up(void);

int main(int argc, char **argv)
{
    int i;
    objeto3D obj;
//    double inc_d_eye_cent     = 10;
    double d_eye_cent_defecto = 3000;
    double d_eye_cent         = 3000;


    //Inicializar modo gráfico
    if(inicializar_modo_grafico() == false)
    {
        printf("No se pudo inicializar SDL: %s\n", SDL_GetError());
        return EXIT_FAILURE;
    }

    // Asegurarse que SDL termina bien antes de salirse
    atexit(clean_up);

    obj = definir_objeto("shuttle.txt", 80);

    punto2D *ppant;
    ppant = (punto2D *)malloc(obj.nv*sizeof(punto2D));
    if (ppant == NULL)
    {
        printf("No hay memoria suficiente para localizar los puntos\n");
        perror("malloc(): ");
        exit(EXIT_FAILURE);
    }

    // Definir el color blanco
    Uint32 color_blanco = SDL_MapRGBA(screen->format, 0xFF,0xFF,0xFF,255);

    // Poner el lienzo de color blanco
    SDL_FillRect(screen, &screen->clip_rect, color_blanco);

    // Actualizar el lienzo
    if(SDL_Flip(screen) == -1) return EXIT_FAILURE;

    // Permite repetir teclas
    // parametro 1: que tanto se debe esperar en ms antes de empezar a repetir
    // parametro 2: cada cuanto tiempo en ms se genera el evento
    SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);

    // ciclo principal
    bool salirse = false;
    do
    {
        while (SDL_PollEvent(&event))
        {
            // leer los mensajes
            switch (event.type)
            {
            case SDL_QUIT:    // salirse si con el mouse se cierra la ventana
                salirse = true;
                break;
            case SDL_KEYDOWN: // si se presiona una tecla
                switch(event.key.keysym.sym)
                {
                case SDLK_ESCAPE:
                    salirse = true;
                    break;
                case SDLK_UP:
                    V = rot_x_en_u(V,E,-ang);
                    N = recalc_N();
                    break;
                case SDLK_DOWN:
                    V = rot_x_en_u(V,E,ang);
                    N = recalc_N();
                    break;
                case SDLK_RIGHT:
                    V = rot_x_en_u(V,N,ang);
                    E = recalc_E();
                    break;
                case SDLK_LEFT:
                    V = rot_x_en_u(V,N,-ang);
                    E = recalc_E();
                    break;
                // SDLK_RCTRL = 305,
                // SDLK_LCTRL = 306,
                // KMOD_LCTRL = 0x0040,
                // KMOD_RCTRL = 0x0080, http://sdl.beuc.net/sdl.wiki/SDL_GetKeyState
                // #define KMOD_CTRL (KMOD_LCTRL|KMOD_RCTRL)        Ver SDL_GetModState
/*
                case (KMOD_CTRL & SDLK_RIGHT):
                    N = rot_x_en_u(N,V,-ang);
                    E = recalc_E();
                    break;
                case (KMOD_CTRL & SDLK_LEFT):
                    N = rot_x_en_u(N,V,ang);
                    E = recalc_E();
                    break;
                case '>':
                    scaling_factor *= inc_scaling_factor;
                    break;  // SDLK_GREATER
                case '<':
                    scaling_factor /= inc_scaling_factor;
                    break;
                case SDLK_PLUS: // +
                    d_eye_cent += inc_d_eye_cent;
                    break;
                case SDLK_LESS: // -
                    if (d_eye_cent>1) d_eye_cent -= inc_d_eye_cent;
                    break; // SDLK_MINUS
*/
                case SDLK_HOME:
                    E = ii;
                    N = jj;
                    V = kk;
                    scaling_factor = 1;
                    d_eye_cent = d_eye_cent_defecto;
                    break;
                } // end switch(event.key.keysym.sym)
            } // end switch(event.type)
        }

        eye = esc_por_vect(d_eye_cent, V);
        for (i=0; i<obj.nv; i++)
            ppant[i] = plano_a_pantalla(proy_central(obj.lv[i]));

        // Poner el lienzo en blanco
        SDL_FillRect(screen, NULL, color_blanco);

        // Dibujar la nave linea a linea (de color negro)
        for (i=0; i<obj.na; i++)
            lineRGBA(screen, ppant[obj.la[i].p1].x, ppant[obj.la[i].p1].y,
                     ppant[obj.la[i].p2].x, ppant[obj.la[i].p2].y, 0, 0, 0, 255);

        // Actualizar el lienzo
        if(SDL_Flip(screen) == -1) return EXIT_FAILURE;

        // Hacer un pausa de 50 ms
//        SDL_Delay(50);

    }
    while (!salirse);

    // clean_up();
    free(ppant);
    return EXIT_SUCCESS;
};

bool inicializar_modo_grafico(void)
{
    // Initializar todos los subsistemas SDL
    if(SDL_Init(SDL_INIT_EVERYTHING) == -1) return false;

    // Configurar el lienzo
    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP, SDL_HWSURFACE);

    // Si hubo un error configurando un lienzo retorne
    if( screen == NULL )
    {
        printf("No se pudo poner el video en modo 640x480: %s\n", SDL_GetError());
        return false;
    }

    // Escribir el título de la ventana
    SDL_WM_SetCaption("Oprima las flechas para mover la nave", NULL);

    maxx = SCREEN_WIDTH;   // screen->w
    maxy = SCREEN_HEIGHT;  // screen->h
    xcen = maxx/2;
    ycen = maxy/2;

    // Si todo se inicializó correctamente retorne un true
    return true;
}

void clean_up(void)
{
    // Devolver la memoria de la superficie
    // SDL_FreeSurface( dot );

    // Salirse del modo SDL
    SDL_Quit();
}
