#ifndef OBJETO_H
#define OBJETO_H

#include "vector3.h"

// *** *** se definen las estructuras *** ***
typedef struct
{
    int p1, p2;
} arista;

typedef struct
{
    int nv;       // número de vértices
    int na;       // número de aristas
    vector3 *lv;  // lista de vértices
    arista *la;   // lista de aristas
} objeto3D;




// *** *** se definen los prototipos de funciones *** ***
objeto3D definir_objeto(const char *nombrearchivo, double escala);
void destruir_objeto(objeto3D obj, double escala);
#endif
