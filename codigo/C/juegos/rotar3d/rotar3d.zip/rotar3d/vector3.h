#ifndef VECTOR3_H
#define VECTOR3_H

#include <stdio.h>
#include <math.h>

// *** *** se definen las estructuras *** ***
typedef struct
{
    double x, y, z;
} vector3;



// *** *** se definen las constantes *** ***
const extern vector3 ii, jj, kk;



// *** *** se definen los prototipos de funciones *** ***
vector3 suma(vector3 a, vector3 b);
vector3 resta(vector3 a, vector3 b);
vector3 prod_cruz(vector3 a, vector3 b);
double prod_punto(vector3 a,vector3 b);
double norma(vector3 b);
vector3 unitario(vector3 b);
vector3 esc_por_vect(double esc, vector3 b);
double dist_punto_vector3(vector3 p, vector3 v);
void imprimir(vector3 b);
#endif
