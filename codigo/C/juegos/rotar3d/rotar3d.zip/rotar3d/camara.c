// Librar�a para el manejo de las transformaciones y proyecciones 3D
#include "camara.h"
#include "vector3.h"

// **** *** se definen las variables globales *** ***
double scaling_factor     = 1;
double inc_scaling_factor = 1.01;

// N y E son los vectores unitario que definen el plano de proyeccion
// V es el vector unitario normal al plano de proyeccion
vector3 E = {.x = 1, .y = 0, .z = 0};
vector3 N = {.x = 0, .y = 1, .z = 0};
vector3 V = {.x = 0, .y = 0, .z = 1};

int xcen, ycen; // (xcen,ycen) = coordenadas del punto central de la pantalla

// en la proteccion central representa la posicion del OJO observador
vector3 eye = {.x = -100, .y = 0, .z = 0};

// *** *** se definen las funciones *** ***
// rota un punto x alrededor del vector u un angulo w
vector3 rot_x_en_u(vector3 x, vector3 u, double w)
{
// F�rmula de rotaci�n de Rodrigues:
// http://en.wikipedia.org/wiki/Rodrigues%27_rotation_formula
    double cosw = cos(w);
    double sinw = sin(w);
    vector3 rot;
    u = unitario(u);
    vector3 proy_x_en_u = esc_por_vect(prod_punto(u,x), u);
    vector3 prod_cruz_u_x = prod_cruz(u,x);
    rot.x = proy_x_en_u.x + cosw*(x.x - proy_x_en_u.x) + sinw*prod_cruz_u_x.x;
    rot.y = proy_x_en_u.y + cosw*(x.y - proy_x_en_u.y) + sinw*prod_cruz_u_x.y;
    rot.z = proy_x_en_u.z + cosw*(x.z - proy_x_en_u.z) + sinw*prod_cruz_u_x.z;

    return rot;
}

// calcula la proyecci�n normal de un punto x sobre el plano
vector3 proy_normal(vector3 x)
{
    //p es la distancia del punto (0,0,0) al plano
    double p = 100;

    // proy = x + (p - prod_punto(x,V))*V
    double lambda = p - prod_punto(x,V);
    return suma(x, esc_por_vect(lambda, V));
}

// calcula la proyecci�n central de un punto x sobre el plano
vector3 proy_central(vector3 x)
{
    //p es la distancia del punto (0,0,0) al plano
    double p = 100;

    // proy = x + ((p - prod_punto(V,x))/prod_punto(V,x-eye)) * (x-eye)
    double lambda = (p - prod_punto(V,x))/prod_punto(V,resta(x,eye));
    return suma(x, esc_por_vect(lambda, resta(x, eye)));
}

// toma un punto p que est� sobre el plano y calcula las coordenadas en la pantalla
punto2D plano_a_pantalla(vector3 pun)
{
    punto2D pantalla;
    pantalla.x = (int) (xcen + scaling_factor*prod_punto(pun,E));
    pantalla.y = (int) (ycen - scaling_factor*prod_punto(pun,N));

    return pantalla;
}

inline vector3 recalc_N(void)
{
    return prod_cruz(V,E);
}

inline vector3 recalc_E(void)
{
    return prod_cruz(N,V);
}
