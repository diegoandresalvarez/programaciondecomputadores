// Librería para el manejo de vectores en R3
#include "vector3.h"

// *** *** se definen las constantes *** ***
const vector3 ii = {.x = 1, .y = 0, .z = 0};
const vector3 jj = {.x = 0, .y = 1, .z = 0};
const vector3 kk = {.x = 0, .y = 0, .z = 1};



// *** *** se definen las funciones *** ***
// suma de vectores: a + b
vector3 suma(vector3 a, vector3 b)
{
    vector3 s;
    s.x = a.x + b.x;
    s.y = a.y + b.y;
    s.z = a.z + b.z;
    return s;
}

// resta de vectores: a - b
vector3 resta(vector3 a, vector3 b)
{
    vector3 r;
    r.x = a.x - b.x;
    r.y = a.y - b.y;
    r.z = a.z - b.z;
    return r;
}

// producto cruz: a x b
vector3 prod_cruz(vector3 a, vector3 b)
{
//	r = a x b
    vector3 r;
    r.x = a.y*b.z - a.z*b.y;
    r.y = a.z*b.x - a.x*b.z;
    r.z = a.x*b.y - a.y*b.x;
    return r;
};

// producto punto: (a,b)
double prod_punto(vector3 a,vector3 b)
{
    return (a.x*b.x + a.y*b.y + a.z*b.z);
}

// norma de un vector: ||b||
double norma(vector3 b)
{
    return sqrt(b.x*b.x + b.y*b.y + b.z*b.z);
}

// normalizar un vector: b/||b||
vector3 unitario(vector3 b)
{
    double norm = norma(b);
    vector3 unit;

    unit.x = b.x/norm;
    unit.y = b.y/norm;
    unit.z = b.z/norm;
    return unit;
}

// escalar por un vector: esc*b
vector3 esc_por_vect(double esc, vector3 b)
{
    vector3 n;

    n.x = esc * b.x;
    n.y = esc * b.y;
    n.z = esc * b.z;
    return n;
}

// distancia de un punto p a su proyeccción sobre un vector unitario v
double dist_punto_vector3(vector3 p, vector3 v)
{
    /*
         *p
        /|
       / |
      /  | ----> distancia medida = p - (p,v)*v
     /   |
    /----+-----> v (es unitario)
    */
    return norma(resta(p, esc_por_vect(prod_punto(p,v), v)));
};

void imprimir(vector3 b)
{
    printf("x = %f, y = %f, z = %f\n", b.x, b.y, b.z);
}
