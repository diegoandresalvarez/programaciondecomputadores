#include <stdio.h>
#include <stdlib.h>
#include "objeto.h"

// *** *** se definen las funciones *** ***
// Lee el objeto a representar desde un archivo
objeto3D definir_objeto(const char *nombrearchivo, double escala)
{
    FILE *datos;
    int i;
    double x, y, z;
    objeto3D obj;

    datos = fopen(nombrearchivo,"rt");

    fscanf(datos,"%d",&obj.nv);
    obj.lv = (vector3 *) malloc(obj.nv*sizeof(vector3));
    if (obj.lv == NULL)
    {
        printf("No hay memoria suficiente para localizar los puntos\n");
        perror("malloc(): ");
        exit(EXIT_FAILURE);
    }

    for (i=0; i<obj.nv; i++)
    {
        fscanf(datos,"%lf %lf %lf",&x, &y, &z);
        obj.lv[i].x = x/escala;
        obj.lv[i].y = y/escala;
        obj.lv[i].z = z/escala;
    }

    fscanf(datos,"%d",&obj.na);
    obj.la = (arista *) malloc(obj.na*sizeof(arista));
    if (obj.la == NULL)
    {
        printf("No hay memoria suficiente para localizar las aristas\n");
        perror("malloc(): ");
        exit(EXIT_FAILURE);
    }

    for (i=0; i<obj.na; i++)
    {
        fscanf(datos,"%lf %lf",&x, &y);
        obj.la[i].p1 = (int)x-1;
        obj.la[i].p2 = (int)y-1;
    }

    fclose(datos);
    return obj;
}

// Retorna la memoria del objeto representado
void destruir_objeto(objeto3D obj, double escala)
{
    if ((obj.la == NULL) || (obj.lv == NULL)) return;
    free(obj.la);
    free(obj.lv);
}
