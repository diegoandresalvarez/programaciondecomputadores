/*
   En este archivo se escribir�n algunas
   funciones relacionadas con el calculo
   del perimetro del circulo
*/

// Se definen las constantes
const double PI = 3.14159265358979;

// Se ponen los encabezados de las funciones
double perimetro(double r);

// Definicion de funciones
double perimetro(double r)
{
   return (2*PI*r);
}
