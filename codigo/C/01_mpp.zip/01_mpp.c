/*
   Este programa sirve para calcular
   el perimetro y el area de una circunferencia,
   dado el radio del mismo.
*/
#include <stdio.h> 
#include "01_calc_circ.h"

// Se definen las variables
double r, A, p;

int main(void)
{
   // Entramos los datos
   printf("Entre el radio (en m) = ");
   scanf("%lf",&r);

   // Ahora realizamos los calculos
   p = perimetro(r);  // se calcula el perimetro
   A = PI*r*r;        // Se calcula el �rea

   // Finalmente se imprimen los resultados
   printf("El perimetro del circulo es %f"
          "m y su area es %f m^2\n", p, A);

   // Codigo de salida exitoso es 0
   return 0;
}

