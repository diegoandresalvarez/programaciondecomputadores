# -*- coding: utf-8 -*-
# Adaptado de: http://inventwithpython.com/chapter19.html

import sys
import random
import pygame
from pygame import K_LEFT, K_RIGHT, K_UP, K_DOWN, K_a, K_s, K_d, K_w

# set up pygame
pygame.init()
mainClock = pygame.time.Clock()

# set up the window
WINDOWWIDTH = 400
WINDOWHEIGHT = 400
windowSurface = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
pygame.display.set_caption('Sprites and Sound')

# set up the colors
BLACK = (0, 0, 0)

# set up the block data structure
# the top left corner of the player is located at (300, 100) and the player
# will have a height and width of 40 pixels to start.
player = pygame.Rect(300, 100, 40, 40)

# Se carga una imagen
playerImage = pygame.image.load('player.png').convert()

# The first argument for pygame.transform.scale is a pygame.Surface object with
# the image drawn on it. The second argument is a tuple for the new width and
# height of the image in the first argument. This function returns a
# pygame.Surface object with the image drawn at a new size. We will store the
# original image in the playerImage variable but the stretched image in the
# playerStretchedImage variable.
playerStretchedImage = pygame.transform.scale(playerImage, (40, 40))
foodImage = pygame.image.load('cherry.png').convert()
foods = []
for i in range(20):
    foods.append(pygame.Rect(random.randint(0, WINDOWWIDTH - 20), 
                             random.randint(0, WINDOWHEIGHT - 20), 20, 20))

foodCounter = 0
NEWFOOD = 40

# set up keyboard variables
moveLeft = moveRight = moveUp = moveDown = False

MOVESPEED = 6

# set up the music and sounds
# The pygame.mixer module can play short sound effects during the game.
# The pygame.mixer.music module can play background music.
pickUpSound = pygame.mixer.Sound('pickup.wav')
pygame.mixer.music.load('background.mid')

# The first parameter for pygame.mixer.music.play tells Pygame how many times
# to play the background music after the first time we play it. So passing 5
# will cause Pygame to play the background music 6 times. -1 is a special
# value, and passing it for the first parameter makes the background music
# repeat forever.
# The second parameter to pygame.mixer.music.play() is the point in the sound
# file to start playing. Passing 0.0 will play the background music starting
# from the beginning. Passing 2.5 for the second parameter will start the
# background  music two and half seconds from the beginning.
pygame.mixer.music.play(-1, 0.0)
musicPlaying = True

# run the game loop
while True:
    # check for the QUIT event
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.KEYDOWN:
            # change the keyboard variables
            if event.key in (K_LEFT,  K_a): moveLeft, moveRight = True,  False
            if event.key in (K_RIGHT, K_d): moveLeft, moveRight = False, True
            if event.key in (K_UP,    K_w): moveDown, moveUp    = False, True
            if event.key in (K_DOWN,  K_s): moveDown, moveUp    = True,  False
        if event.type == pygame.KEYUP:
            if event.key in (pygame.K_ESCAPE, pygame.K_q):
                pygame.quit()
                sys.exit()
            if event.key in (K_LEFT,  K_a): moveLeft  = False
            if event.key in (K_RIGHT, K_d): moveRight = False
            if event.key in (K_UP,    K_w): moveUp    = False
            if event.key in (K_DOWN,  K_s): moveDown  = False
            if event.key == pygame.K_x:
                player.top  = random.randint(0, WINDOWHEIGHT - player.height)
                player.left = random.randint(0, WINDOWWIDTH  - player.width)
            if event.key == pygame.K_m:
                # toogling the music on and off
                if musicPlaying:
                    pygame.mixer.music.stop()
                else:
                    pygame.mixer.music.play(-1, 0.0)
                musicPlaying = not musicPlaying

        if event.type == pygame.MOUSEBUTTONUP:
            foods.append(pygame.Rect(event.pos[0] - 10, event.pos[1] - 10, 20, 20))

    foodCounter += 1
    if foodCounter >= NEWFOOD:
        # add new food
        foodCounter = 0
        foods.append(pygame.Rect(random.randint(0, WINDOWWIDTH  - 20), 
                                 random.randint(0, WINDOWHEIGHT - 20), 20, 20))

    # draw the black background onto the surface
    windowSurface.fill(BLACK)

    # move the player
    if moveDown  and player.bottom < WINDOWHEIGHT: player.top   += MOVESPEED
    if moveUp    and player.top > 0:               player.top   -= MOVESPEED
    if moveLeft  and player.left > 0:              player.left  -= MOVESPEED
    if moveRight and player.right < WINDOWWIDTH:   player.right += MOVESPEED

    # draw the block onto the Surface windowSurface the Surface playerStretchedImage
    # at the position Rect player
    windowSurface.blit(playerStretchedImage, player)

    # check if the block has intersected with any food squares.
    for food in foods[:]:
        if player.colliderect(food):
            foods.remove(food)
            player = pygame.Rect(player.left, player.top, player.width + 2, player.height + 2)
            playerStretchedImage = pygame.transform.scale(playerImage, (player.width, player.height))
            if musicPlaying:
                pickUpSound.play()

    # draw the food
    for food in foods:
        windowSurface.blit(foodImage, food)

    # draw the window onto the screen
    pygame.display.update()
    mainClock.tick(40)
