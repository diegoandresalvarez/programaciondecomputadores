# Tomado de:
# https://www.pygame.org/docs/tut/intro/intro.html

import time
import sys
import pygame

# Se definen las constantes
ANCHOVENTANA = 640
ALTOVENTANA  = 480
VELOCIDAD = [3, 3]  # movimiento en pixeles en dirs (x,y)

# Se definen los colores RGB
NEGRO = (0, 0, 0)

# Se inicializa el modo "pygame"
pygame.init()

# Se crea el objeto tipo "Surface" que representa la pantalla
ventana = pygame.display.set_mode((ANCHOVENTANA,ALTOVENTANA))
print('type(ventana) =', type(ventana))

# Se carga una imagen .PNG, .JPG, .GIF, .PNG, .TGA
# Este comando crea un objeto tipo "Surface" que representa la pelota
# El comando conserva la paleta de colores y la transparencia de la imagen
pelota = pygame.image.load("pelota.gif").convert_alpha()
print('type(pelota) =', type(pelota))

# pelota_rect es de tipo Rect: tipo de objeto que representa un rectángulo
pelota_rect = pelota.get_rect()
print('type(pelota_rect) =', type(pelota_rect))

# El ciclo principal del juego
while True:
    # Se buscan los eventos generados por el usuario
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Se actualiza la posición de la pelota
    # pelota_rect = pelota_rect.move(VELOCIDAD)  # es equivalente a:
    pelota_rect.move_ip(VELOCIDAD)

    # Se verifica si la pelota golpeó los bordes de la ventana
    if pelota_rect.left < 0 or pelota_rect.right > ANCHOVENTANA:
        VELOCIDAD[0] = -VELOCIDAD[0]
    if pelota_rect.top < 0 or pelota_rect.bottom > ALTOVENTANA:
        VELOCIDAD[1] = -VELOCIDAD[1]

    # Se rellena la pantalla de color negro
    ventana.fill(NEGRO)

    # Se copian los pixeles desde "pelota" hasta "ventana", uno a uno, en las
    # coordenadas especificadas por pelota_rect
    ventana.blit(pelota, pelota_rect)

    # Se actualiza la pantalla
    pygame.display.update()
    # pygame.display.flip()

    time.sleep(0.01)
