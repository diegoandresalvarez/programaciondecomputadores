def definir_objeto(nombre_archivo, escala=1):  
    '''
    Lee el objeto a representar desde el archivo "nombre_archivo"
    '''
    # Se abre el archivo
    archivo = open(nombre_archivo,'r')
    
    # Se leen todas las líneas del archivo
    lineas = archivo.readlines()
    
    # Se cierra el archivo
    archivo.close()
    
    # Se convierten los datos leídos del archivo a una gran lista
    M = []
    for linea in lineas:
        L = linea.split(' ')    
       
        # Se convierte cada una de las cadenas a un número
        M.append([int(x) for x in L])
    
    # Se separan los componentes de la lista:
    npuntos = int(M[0][0])
    puntos  = M[1:npuntos+1]
    
    # Se escalan las coordenadas de los vértices
    for i in range(npuntos):
        for j in (0,1,2):
            puntos[i][j] /= escala
            
    nlineas = int(M[npuntos+1][0])
    lineas  = M[npuntos+2:]
    
    # Se ajustan las coordenadas de las aristas
    for i in range(nlineas):
        lineas[i][0] -= 1
        lineas[i][1] -= 1        
        
    
    return npuntos, puntos, nlineas, lineas

if __name__ == '__main__':
    # nv, lv: número y lista de vertices
    # na, la: número y lista de aristas
    nv, lv, na, la = leer_archivo('shuttle.txt',1) 