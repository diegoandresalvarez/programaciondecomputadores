'''
PROGRAMA VISUALIZADOR DE OBJETOS 3D
Elaborador por Diego Andres Alvarez Marín (daalvarez@unal.edu.co)
El programa muestra el objeto con una vista en perspectiva
Utilice las flechas para mover el objeto
 + para alejar la c mara (haciendo una proyeccion mas ortogonal
 - para alejar la camara (haciendo una proyeccion mas en perspectiva
 < y > para hacer zoom
 Home para volver al estado inicial
 Ctrl+ flecha izq y Ctrl + flecha der para girar el objeto alrededor del plano 
 normal a la pantalla
'''

import pygame
from pygame.locals import *
import sys, camara

from vector3 import ii, jj, kk, esc_por_vect
from objeto import definir_objeto

## Se definen las constantes
d_eye_cent_defecto = 3000
d_eye_cent         = 3000    
ang                = 0.1

# Se definen los atributos de la pantalla
SCREEN_WIDTH  = 640         
SCREEN_HEIGHT = 480

# Se definen los colores
BLANCO = (255,255,255)
NEGRO  = (0,0,0)

# (xcen,ycen) son las coordenadas del punto central de la pantalla;
camara.xcen = SCREEN_WIDTH/2;
camara.ycen = SCREEN_HEIGHT/2;

## Comienza el programa principal
# Se define el objeto a mostrar y se establece su escala
nv, lv, na, la = definir_objeto("nave.txt", 80)

# Se separa la memoria para las coordenadas de los puntos en la pantalla
ppant = [[None, None]]*nv

# Inicializar modo gráfico
pygame.init()    
mainClock = pygame.time.Clock()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Se coloca el título a la ventana
pygame.display.set_caption('Mueva la nave con las flechas')    

# Poner el lienzo de color blanco
screen.fill(BLANCO)

# Se vacía el lienzo a la pantalla
pygame.display.update()

# Ciclo principal
salirse = False    
while True:
    # Revisar la lista de eventos generados
    for event in pygame.event.get(): 
        # Salirse si el mouse cierra la ventana
        if event.type == QUIT:                
            pygame.quit()
            sys.exit()
        # Si se presiona una tecla
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE:
                pygame.quit()
                sys.exit()
            if event.key == K_HOME:
                camara.E = ii[:]
                camara.N = jj[:]
                camara.V = kk[:]
                camara.scaling_factor = 1
                d_eye_cent = d_eye_cent_defecto            

    # De acuerdo con:
    # https://www.pygame.org/docs/ref/key.html#comment_pygame_key_get_pressed
    # Antes de llamar pygame.key.get_pressed(), se debe llamar pygame.event.pump() 
    # para obtener el estado actual del teclado
    pygame.event.pump()                
    presionada = pygame.key.get_pressed()  # que teclas se han presionado?
    if presionada[K_UP]:
        camara.V = camara.rot_x_en_u(camara.V,camara.E,-ang)
        camara.N = camara.recalc_N()
    if presionada[K_DOWN]:            
        camara.V = camara.rot_x_en_u(camara.V,camara.E,ang)
        camara.N = camara.recalc_N()
    if presionada[K_RIGHT]:
        camara.V = camara.rot_x_en_u(camara.V,camara.N,ang)
        camara.E = camara.recalc_E()                  
    if presionada[K_LEFT]:
        camara.V = camara.rot_x_en_u(camara.V,camara.N,-ang)
        camara.E = camara.recalc_E()

    camara.eye = esc_por_vect(d_eye_cent, camara.V)
    for i in range(nv):
        #ppant[i] = camara.plano_a_pantalla(camara.proy_central(lv[i]))
        # No es necesario realizar la proyección central, ya que por álgebra 
        # lineal el punto se proyecta directamente a los vectores E y N.        
        ppant[i] = camara.plano_a_pantalla(lv[i])

    # Poner el lienzo de color blanco
    screen.fill(BLANCO)

    # Dibujar la nave linea a linea (de color negro)
    for i in range(na):
        pygame.draw.line(screen, NEGRO, \
        (ppant[la[i][0]][0], ppant[la[i][0]][1]), \
        (ppant[la[i][1]][0], ppant[la[i][1]][1]))

    # Se vacía el lienzo a la pantalla
    pygame.display.update()
    mainClock.tick(40)
    
