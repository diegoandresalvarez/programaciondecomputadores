'''
Librería para el manejo de vectores en R3
'''
from math import sqrt

## Se definen las constantes
ii = (1,0,0)
jj = (0,1,0)
kk = (0,0,1)


## Se definen las funciones
def suma(a, b):
    '''
    suma de vectores: a + b
    '''
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def resta(a, b):
    '''
    resta de vectores: a - b
    '''
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def prod_cruz(a, b):
    '''
    Calcula el producto cruz: a x b
    '''
    return (a[1]*b[2] - a[2]*b[1], a[2]*b[0] - a[0]*b[2], a[0]*b[1] - a[1]*b[0])


def prod_punto(a, b):
    '''
    Calcula el producto punto: (a,b)
    '''
    return a[0]*b[0] + a[1]*b[1] + a[2]*b[2]


def norma(b):
    '''
    Calcula la norma de un vector: ||b||
    '''
    return sqrt(b[0]*b[0] + b[1]*b[1] + b[2]*b[2])


def unitario(b):
    '''
    Normaliza un vector: b/||b||
    '''
    norm = norma(b)
    return (b[0]/norm, b[1]/norm, b[2]/norm)


def esc_por_vect(esc, b):
    '''
    Retorna el producto de un escalar por un vector: esc*b
    '''
    return (esc*b[0], esc*b[1], esc*b[2])


def dist_punto_vector3(p, v):
    '''
    Calcula la distancia de un punto p a su proyeccción sobre un vector unitario v
    '''
    #         *p
    #        /|
    #       / |
    #      /  | ----> distancia medida = p - (p,v)*v
    #     /   |
    #    /----+-----> v (es unitario)

    return norma(resta(p, esc_por_vect(prod_punto(p,v), v)))


def imprimir(b):
    '''
    Imprime los componentes de un vector b
    '''
    print("x = %f, y = %f, z = %f\n" % b[0], b[1], b[2])
