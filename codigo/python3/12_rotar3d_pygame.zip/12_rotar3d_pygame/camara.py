## Librería para el manejo de las transformaciones y proyecciones 3D

from vector3 import esc_por_vect, prod_punto, prod_cruz, suma, resta, unitario
from math import sin, cos

## Se definen las variables globales
scaling_factor     = 1
inc_scaling_factor = 1.01

# (xcen,ycen) = coordenadas del punto central de la pantalla
xcen, ycen = None, None

# N y E son los vectores unitario que definen el plano de proyeccion
# V es el vector unitario normal al plano de proyeccion
E = (1,0,0)
N = (0,1,0)
V = (0,0,1)

# Posicion del OJO observador (en la proteccion central)
eye = (-100,0,0)

## Se definen las funciones
def rot_x_en_u(x, u, w):
    '''
    Rota un punto x alrededor del vector u un ángulo w
    '''
    
    # Fórmula de rotación de Rodrigues:
    # http://en.wikipedia.org/wiki/Rodrigues%27_rotation_formula
    cosw = cos(w)
    sinw = sin(w)
       
    u = unitario(u)
    proy_x_en_u = esc_por_vect(prod_punto(u,x), u)
    prod_cruz_u_x = prod_cruz(u,x)
    
    return  proy_x_en_u[0] + cosw*(x[0] - proy_x_en_u[0]) + sinw*prod_cruz_u_x[0],\
            proy_x_en_u[1] + cosw*(x[1] - proy_x_en_u[1]) + sinw*prod_cruz_u_x[1],\
            proy_x_en_u[2] + cosw*(x[2] - proy_x_en_u[2]) + sinw*prod_cruz_u_x[2]


def proy_normal(x):
    '''
    Calcula la proyección normal de un punto x sobre el plano
    '''
    # p es la distancia del punto (0,0,0) al plano
    p = 100

    # proy = x + (p - prod_punto(x,V))*V
    _lambda_ = p - prod_punto(x,V)
    return suma(x, esc_por_vect(_lambda_, V))


def proy_central(x):
    '''
    Calcula la proyección central de un punto x sobre el plano
    '''
    # p es la distancia del punto (0,0,0) al plano
    p = 100

    # proy = x + ((p - prod_punto(V,x))/prod_punto(V,x-eye)) * (x-eye)
    _lambda_ = (p - prod_punto(V,x))/prod_punto(V, resta(x,eye))
    return suma(x, esc_por_vect(_lambda_, resta(x, eye)))


def plano_a_pantalla(pun):
    '''
    Toma un punto p que está sobre el plano y calcula las coordenadas en la pantalla
    '''
    # (xcen,ycen) = coordenadas del punto central de la pantalla
    return int(xcen + scaling_factor*prod_punto(pun,E)),\
           int(ycen - scaling_factor*prod_punto(pun,N))

def recalc_N():
    return prod_cruz(V,E)

def recalc_E():
    return prod_cruz(N,V)
