# PACMAN - Un clon desarrollado en PYTHON 3 usando la librería PYGAME 1.9.2

Primero que todo, es conveniente leer el siguiente documento

* The PACMAN dossier: https://www.gamasutra.com/view/feature/132330/the_pacman_dossier.php

el cual explica la lógica de funcionamiento del juego.

Se debe tener en cuenta que cada una de las figuras del juego tiene un tamaño de 8x8 pixeles. El tablero de juego tiene un tamaño de 224x248 pixeles, por lo que dividiendo estas dimensiones entre 8 se obtiene una cuadrícula de 28x31 figuras

# PYGAME

Se instala con el comando
> pip install pygame
