Hay más sonidos en:
https://github.com/pac1979/PacMan/tree/master/sounds
