# whimsytt.ttf

El archivo **whimsytt.ttf** contine la fuente "Whimsy" desarrollada por "Gary David Bouton"

Nota esta fuente la detecté con:

https://www.fontsquirrel.com/matcherator

y está disponible en:

https://www.fontzillion.com/fonts/gary-david-bouton/whimsy?utm_source=fontsquirrel.com&utm_medium=matcherator_link&utm_campaign=whimsygarydavidbouton
