error.wav se descargó de http://soundbible.com/1127-Computer-Error.html 
