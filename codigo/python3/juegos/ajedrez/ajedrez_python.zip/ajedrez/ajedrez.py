'''
SUPER AJEDREZ 5000
Un juego de ajedrez persona vs persona

Desarrollado por:
Diego Andrés Alvarez Marín (daalvarez@unal.edu.co)
'''

import pygame, sys, time, os 
from pygame.locals import *

## Se definen las constantes
COLOR_NEGRO = (  0, 0, 0)
COLOR_ROJO  = (255, 0, 0)

BLANCA = BLANCAS = 1
NEGRA  = NEGRAS  = 0

ANCHOFIL, ANCHOCOL = 40, 40 # dimensiones de una casilla

# Posición superior izquierda del tablero
XTABLERO, YTABLERO = (480-ANCHOCOL*8)/2, (480-ANCHOFIL*8)/2 

tablero = [
    ['t','c','a','d','r','a','c','t'],  # BLANCAS mayuscula
    ['p','p','p','p','p','p','p','p'],  # NEGRAS  minuscula
    [' ',' ',' ',' ',' ',' ',' ',' '],
    [' ',' ',' ',' ',' ',' ',' ',' '],
    [' ',' ',' ',' ',' ',' ',' ',' '],
    [' ',' ',' ',' ',' ',' ',' ',' '],
    ['P','P','P','P','P','P','P','P'],
    ['T','C','A','D','R','A','C','T']]

turno = BLANCAS  # Empiezan las blancas

# Se inicializan todos los cronómetros en cero
tini = ttotal = tblancas = tnegras = 0

# Línea donde se imprimen los mensajes (movimiento erróneo, jaque, jaque mate)
linea_mensajes = (450, 210, 639-450, 20)

# Línea donde se imprime a quien le toca jugar
linea_turno    = (450,  50, 639-450, 20)

## Se definen las funciones
def dibujar_ficha(f, c):
    '''
    Dibuja la ficha que está en la posición f,c
    '''
    ficha = ['', '', '_', '']
    
    # Si es una casilla vacía
    if tablero[f][c] == ' ':     # Recuerde que 'ca_b' y 'ca_n' son las casillas
        ficha[0:2] = ['c', 'a']  # vacías blanca y negra respectivamente
    else: # Si es una ficha del ajedrez:
        # Ficha blanca o negra (b n)
        ficha[0] = 'b' if (tablero[f][c]).isupper() else 'n'

        # Tipo de ficha: t c a d r p
        ficha[1] = tablero[f][c].lower()

    # Casilla blanca o negra (b n)
    ficha[3] = 'b' if (f+c)%2 == 0 else 'n'
            
    # Se arma el nombre del archivo y a partir de este se accede al diccionario
    # para obtener la imagen de la ficha a dibujar. Luego se grafica la misma
    imagen = imagen_ficha[''.join(ficha)]
    ventana.blit(imagen, (XTABLERO + c*ANCHOCOL,YTABLERO + f*ANCHOFIL))


def dibujar_tablero():
    '''
    Dibuja todo el tablero de juego, incluyendo fichas y tiempo de juego
    '''
    # Se borra la pantalla
    ventana.fill(COLOR_NEGRO)
    
    # Se dibujan todas las fichas
    for i in range(8):
        for j in range(8):
            dibujar_ficha(i,j)

    # Se configura la fuente        
    fuente = pygame.font.SysFont("Arial", 16)        
       
    # Se escribe la barra de estado
    texto = "F1 - Ayuda         F2 - Fichas comidas         ESC - Salir"
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), (1, 460))    
    
    # Se escribe quien juega
    if turno == BLANCAS:
        texto = "Juegan las BLANCAS"
    else:
        texto = "Juegan las NEGRAS"
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), linea_turno)
    
    # Se escriben los tiempos de juego
    texto = "Blancas ="
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), (450, 120))
    
    texto = "Negras  ="
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), (450, 140))
    
    texto = "Total   ="
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), (450, 180))
    
    actualizar_reloj()


def dibujar_cursor(f, c):
    '''
    Dibuja un rectángulo rojo alrededor de la casilla f,c seleccionada
    '''
    # Si no hay una casilla seleccionada, no haga nada
    if (f, c) == (None, None): return
    
    # Se dibuja el rectángulo "cursor"
    x1, y1 = XTABLERO + c*ANCHOCOL+2, YTABLERO + f*ANCHOFIL+2    
    pygame.draw.rect(ventana, COLOR_ROJO, (x1, y1, ANCHOFIL-4, ANCHOCOL-4), 5)
    

def mover_ficha(f1, c1, f2, c2):
    '''
    Mover la ficha de la casilla f1,c1 a la casilla f2,c2.
    
    Retorna:
    True si la ficha se pudo mover exitosamente; de lo contrario retorna False
    '''
    global turno, tablero, tini, tnegras, tblancas

    # Un movimiento inválido sucede cuando:
    # * Se selecciona un espacio vacío
    # * Se selecciona una blanca y el turno es de las negras
    # * Se selecciona una negra y el turno es de las blancas
    # * Se mueve una ficha blanca encima de otra ficha blanca
    # * Se mueve una ficha negra encima de otra ficha negra
    movimiento_invalido = (tablero[f1][c1] == ' ') or \
                (tablero[f1][c1].isupper() and turno == NEGRAS) or \
                (tablero[f1][c1].islower() and turno == BLANCAS) or \
                (tablero[f1][c1].isupper() and tablero[f2][c2].isupper()) or \
                (tablero[f1][c1].islower() and tablero[f2][c2].islower())

    # Si el movimiento es válido verifique si las fichas se están moviendo de
    # acuerdo a las reglas del ajedrez
    if not movimiento_invalido:
        ficha = tablero[f1][c1].upper()
        if ficha == 'P':
            movimiento_invalido = not es_val_mover_peon(f1,c1,f2,c2)
        elif ficha == 'T': 
            movimiento_invalido = not es_val_mover_torre(f1,c1,f2,c2)
        elif ficha == 'C':
            movimiento_invalido = not es_val_mover_caballo(f1,c1,f2,c2)
        elif ficha == 'A': 
            movimiento_invalido = not es_val_mover_alfil(f1,c1,f2,c2)
        elif ficha == 'R': 
            movimiento_invalido = not es_val_mover_rey_y_hacer_enroque(f1,c1,f2,c2)
        elif ficha == 'D': 
            movimiento_invalido = not es_val_mover_dama(f1,c1,f2,c2)

    # Se configura la fuente        
    fuente = pygame.font.SysFont("Arial", 16)        

    if movimiento_invalido:	
        # Imprimir mensaje que el movimiento es inválido. Para tal fin se dibuja
        # el texto a imprimir, se genera un sonido de error, se imprime el 
        # mensaje de error por un segundo y luego se quita
        texto = "Movimiento invalido!!!"
        pygame.draw.rect(ventana, COLOR_NEGRO, linea_mensajes, 0)
        ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), linea_mensajes)
        tocar_sonido_error()
        pygame.display.update()
        time.sleep(1)
        pygame.draw.rect(ventana, COLOR_NEGRO, linea_mensajes, 0)        

        # Se le dice al programa principal que no se pudo mover la ficha
        return False

    # Se mueve la ficha de la posición f1,c1 a la posición f2,c2. En la posición
    # f1,c1 no queda ninguna ficha, por lo que se asigna un espacio
    tablero[f2][c2] = tablero[f1][c1]
    tablero[f1][c1] = ' '

    # A continuación se dibujan las casillas involucradas y se vuelve a dibujar
    # el cursor
    dibujar_ficha(f1,c1)
    dibujar_ficha(f2,c2)
    dibujar_cursor(f2,c2)

    # El turno cambia de las blancas a las negras o viceversa
    turno = not turno 

    # Se imprime como tal el mensaje
    if turno == BLANCAS:
        texto = "Juegan las BLANCAS"
        tnegras += time.time() - tini
    else:
        texto = "Juegan las NEGRAS"
        tblancas += time.time() - tini

    pygame.draw.rect(ventana, COLOR_NEGRO, linea_turno, 0)
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), linea_turno)

    # Empieza a contar el cronómetro para el jugador actual
    tini = time.time()
    
    # Se le dice al programa principal que la ficha se movió exitosamente
    return True


def tocar_sonido_error():
    '''
    Hace que se genere una alerta sonora que significa que hubo un error en 
    algún movimiento.
    '''
    nombre_archivo = os.path.join('sound','error.wav')
    try:
        error_sound = pygame.mixer.Sound(nombre_archivo)    
        error_sound.play()
    except pygame.error:
        texto_error = 'No se pudo cargar el archivo {0}.\n{1}'.\
            format(nombre_archivo, pygame.get_error())
        pygame.quit()
        raise SystemExit(texto_error)  

def actualizar_reloj():    
    '''
    Imprime los relojes de juego en la pantalla
    '''
    global tjugada, ttotal

    # Se configura la fuente
    fuente = pygame.font.SysFont("Arial", 16)

    # Se calcula el tiempo de juego durante el presente movimiento
    tjugada = time.time() - tini
    
    # Se actualiza e imprime el tiempo total de juego
    ttotal = tblancas + tnegras + tjugada        
    h = int(ttotal/3600)
    m = int((ttotal - 3600*h)/60)
    s = int(ttotal - 3600*h - 60*m)
    texto = '{0:02d}:{1:02d}:{2:02d}'.format(h,m,s)
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), (530, 180))

    # Se actualiza e imprime el tiempo total de juego de las blancas
    t = tjugada + tblancas if turno == BLANCAS else tblancas
    h = int(t/3600)
    m = int((t - 3600*h)/60)
    s = int(t - 3600*h - 60*m)
    texto = '{0:02d}:{1:02d}:{2:02d}'.format(h,m,s)
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), (530, 120))

    # Se actualiza e imprime el tiempo total de juego de las negras    
    t = tjugada + tnegras if turno == NEGRAS else tnegras
    h = int(t/3600)
    m = int((t - 3600*h)/60)
    s = int(t - 3600*h - 60*m)
    texto = '{0:02d}:{1:02d}:{2:02d}'.format(h,m,s)
    ventana.blit(fuente.render(texto, True, COLOR_ROJO, COLOR_NEGRO), (530, 140))


def mostrar_fichas_comidas():
    pass

def mostrar_ayuda():
    pass

def es_val_mover_peon(f1, c1, f2, c2):
    return True

def es_val_mover_torre(f1, c1, f2, c2):
    return True

def es_val_mover_caballo(f1, c1, f2, c2):
    return True

def es_val_mover_alfil(f1, c1, f2, c2):
    return True

def es_val_mover_alfil(f1, c1, f2, c2):
    return True

def es_val_mover_rey_y_hacer_enroque(f1, c1, f2, c2):
    return True

def es_val_mover_dama(f1, c1, f2, c2):
    return True

    
########## ########## ######## PROGRAMA PRINCIPAL ######## ########## ########## 
# Nombres de los archivos que contienen las fichas (.bmp)
archivos = ["ba_b", "ba_n", "bc_b", "bc_n", # Letra 0: color ficha
            "bd_b", "bd_n", "bp_b", "bp_n", #     b: blanca, n:negra, c:casilla
            "br_b", "br_n", "bt_b", "bt_n", # Letra 1: tipo ficha
            "ca_b", "ca_n",                 #     t: torre, c: caballo, a: alfil
            "na_b", "na_n", "nc_b", "nc_n", #     d: dama,  r: rey,     p: peón
            "nd_b", "nd_n", "np_b", "np_n", # Letra 3: color casilla
            "nr_b", "nr_n", "nt_b", "nt_n"] #     b: blanca, n:negra

# Se inicializa el modo PYGAME
pygame.init()

# Se leen las imágenes del disco y se almacenan en un diccionario
imagen_ficha = {}      # diccionario vacío
for archivo in archivos:
    # Se crea la ruta del nombre del archivo a cargar. La función os.path.join()
    # concatena o produce el nombre del archivo de modo que se pueda correr 
    # bajo cualquier sistema operativo.    
    nombre_archivo = os.path.join('set', archivo + '.bmp')
    try:
        imagen_ficha[archivo] = pygame.image.load(nombre_archivo)
    except pygame.error:
        texto_error = 'No se pudo cargar la imagen {0}.\n{1}'.\
            format(nombre_archivo, pygame.get_error())
        pygame.quit()
        raise SystemExit(texto_error)

# Se inicializa la ventana de juego
ventana = pygame.display.set_mode((640, 480)) #, FULLSCREEN)
pygame.display.set_caption('Ajedrez')

tini = time.time() # toca ponerlo para que se imprima el tiempo en ceros
dibujar_tablero()
fcur_act, ccur_act =  6,  4 # posicion inicial del cursor P2R (peón 2 rey)
fcur_sel, ccur_sel = None, None
dibujar_cursor(fcur_act, ccur_act)
casilla_seleccionada = False # al principio del juego no hay casilla seleccionada
    
# Se configura la fuente
fuente = pygame.font.SysFont("Arial", 16)        
   
# Ahora sí comienza a funcionar el reloj del juego
tini = time.time()

# Comienza el bucle principal del juego
while True:
    actualizar_reloj()
    
    for event in pygame.event.get():
        if event.type == QUIT: # si se presiona con el mouse la X de la ventana
            pygame.quit()
            sys.exit()
        if event.type == KEYDOWN:
            if event.key == K_ESCAPE: # si se presiona ESCAPE, se sale del juego
                pygame.quit()
                sys.exit()
            if event.key == K_UP:     # FLECHA_ARRIBA
                # Se redibuja la ficha actual para borrar el recuadro, luego si 
                # es posible, se mueve el cursor. Si hay una ficha seleccionada
                # se dibuja el cursor sobre dicha ficha y finalmente se dibuja
                # el recuadro en la nueva posición a donde se movió el cursor
                dibujar_ficha(fcur_act, ccur_act)
                if fcur_act>0: fcur_act -= 1
                if casilla_seleccionada: dibujar_cursor(fcur_sel, ccur_sel)
                dibujar_cursor(fcur_act, ccur_act)
            if event.key == K_DOWN:   # FLECHA_ABAJO
                dibujar_ficha(fcur_act, ccur_act)
                if fcur_act<7: fcur_act += 1
                if casilla_seleccionada: dibujar_cursor(fcur_sel, ccur_sel)
                dibujar_cursor(fcur_act, ccur_act)
            if event.key == K_LEFT:   # FLECHA_IZQUIERDA
                dibujar_ficha(fcur_act, ccur_act)
                if ccur_act>0: ccur_act -= 1
                if casilla_seleccionada: dibujar_cursor(fcur_sel, ccur_sel)
                dibujar_cursor(fcur_act, ccur_act)
            if event.key == K_RIGHT:  # FLECHA_DERECHA       
                dibujar_ficha(fcur_act, ccur_act)
                if ccur_act<7: ccur_act += 1
                if casilla_seleccionada: dibujar_cursor(fcur_sel, ccur_sel)
                dibujar_cursor(fcur_act, ccur_act)
            if event.key == K_RETURN: # ENTER
                if not casilla_seleccionada:
                    if tablero[fcur_act][ccur_act] == ' ':
                        # Si se seleccionó un espacio vacío, advertir al usuario
                        # que debe seleccionar una ficha, tocar el sonido de 
                        # advertencia y al segundo quitar dicha advertencia de 
                        # la pantalla
                        texto = "Seleccione una ficha!!!"
                        pygame.draw.rect(ventana, COLOR_NEGRO, linea_mensajes, 0)        
                        ventana.blit(fuente.render(texto, True, COLOR_ROJO), linea_mensajes)
                        tocar_sonido_error()
                        pygame.display.update()
                        time.sleep(1)        
                        pygame.draw.rect(ventana, COLOR_NEGRO, linea_mensajes, 0)                                   
                    else:
                        # La casilla actual se vuelve la seleccionada. 
                        fcur_sel, ccur_sel = fcur_act, ccur_act                        
                        casilla_seleccionada = True
                elif fcur_act==fcur_sel and ccur_act==ccur_sel: 
                    # De lo contrario si se selecciona la casilla seleccionada,
                    # se desactiva esta y quedamos sin casilla seleccionada                    
                    fcur_sel, ccur_sel  = None, None
                    casilla_seleccionada = False
                else:
                    # Se mueve la ficha de la casilla actual a la seleccionada
                    if mover_ficha(fcur_sel, ccur_sel, fcur_act, ccur_act):
                        casilla_seleccionada = False
            if event.key == K_F1:
                mostrar_ayuda()
            if event.key == K_F2:        
                mostrar_fichas_comidas()
    
        if event.type == MOUSEBUTTONDOWN:
            # Se lee la posición del mouse donde se dió click
            MouseX, MouseY = event.pos    
            
            # Si se presionó el botón izquierdo o derecho del mouse
            if event.button == 1 or event.button == 3: # botón izq, botón der
                # Se encuenta la casilla correspondiente donde se dió click
                cm = int((MouseX - XTABLERO)/ANCHOCOL)                
                fm = int((MouseY - YTABLERO)/ANCHOFIL)
                
                # Si la posición está dentro del tablero de ajedrez
                if (fm>=0) and (fm<=7) and (cm>=0) and (cm<=7):
                    # Se redibuja la ficha actual para borrar el recuadro, luego
                    # se mueve el cursor. Si hay una ficha seleccionada se 
                    # dibuja el cursor sobre dicha ficha y finalmente se dibuja
                    # el recuadro en la nueva posición a donde se movió el cursor
                    dibujar_ficha(fcur_act, ccur_act)
                    fcur_act, ccur_act = fm, cm
                    if casilla_seleccionada: dibujar_cursor(fcur_sel, ccur_sel)
                    dibujar_cursor(fcur_act, ccur_act)
            
            if event.button == 3:
                # Si se presiona el botón derecho del mouse, la casilla se marca
                cm = int((MouseX - XTABLERO)/ANCHOCOL)
                fm = int((MouseY - YTABLERO)/ANCHOFIL)

                # Si la posición está dentro del tablero de ajedrez
                if (fm>=0) and (fm<=7) and (cm>=0) and (cm<=7):
                    dibujar_ficha(fcur_act,ccur_act)
                    if not casilla_seleccionada and fm == fcur_act and cm == ccur_act:
                        # Si no había una casilla seleccionada, y se hizo click
                        # en la posición del cursor, entonces marcar dicha 
                        # casilla como seleccionada
                        fcur_sel, ccur_sel = fcur_act, ccur_act = fm, cm
                        casilla_seleccionada = True
                    elif casilla_seleccionada and fm == fcur_sel == fcur_act \
                                              and cm == ccur_sel == ccur_act:
                        # Si se seleccionó una casilla que ya estaba 
                        # seleccionada, se elimina la selección de esta
                        fcur_sel, ccur_sel = None, None
                        casilla_seleccionada = False
                    elif casilla_seleccionada and fm==fcur_act and cm==ccur_act:
                        # Si ya había una casilla seleccionada, realizar el 
                        # movimiento hacia la casilla donde se seleccionó el 
                        # mouse. En caso que el movimiento se realice con éxito,
                        # decir que no hay casillas seleccionadas
                        if mover_ficha(fcur_sel,ccur_sel,fcur_act,ccur_act):
                            casilla_seleccionada = False

                    # Pintar de nuevo el cursor en la casilla seleccionada y en 
                    # la posición actual del cursor
                    if casilla_seleccionada: dibujar_cursor(fcur_sel, ccur_sel)
                    dibujar_cursor(fcur_act,ccur_act)

    # Actualizar la pantalla
    pygame.display.update()