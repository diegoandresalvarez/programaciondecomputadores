import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((600,400))

# Inicializar colores
FG = 250, 250, 250
BG = 0, 0, 250
COLVENTANA = 80, 80, 90

screen.fill(COLVENTANA)

# Se configuran las fuentes
print('Las fuentes que se pueden utilizar son:', pygame.font.get_fonts())

print('La fuente por defecto es:', pygame.font.get_default_font())
# El primer parámetro es la fuente (aquí se está usando la que está por defecto)
# El segundo parámetro es el tamaño de la fuente.
#font = pygame.font.SysFont(None, 60)             # usa una de las fuentes del sistema
font = pygame.font.Font('Comic_Sans_MS.ttf', 40)  # usa la fuente del archivo
text = 'Fuente'

# Se determina la cantidad de espacio requerido por el texto
size = font.size(text)

# No antialiasing, no transparency, normal
# Se configura el texto
# Texto, AliasedText=True/False, ForegroundColor, BackgroundColor
ren = font.render(text, False, FG, BG)
screen.blit(ren, (10, 10))

# No antialiasing, transparency, underline
font.set_underline(True)
ren = font.render(text, False, FG)
screen.blit(ren, (10, 40 + size[1]))
font.set_underline(False)

arial_font = pygame.font.SysFont('arial', 60)

# Antialiased, no transparency, bold
arial_font.set_bold(True)
ren = arial_font.render(text, True, FG, BG)
screen.blit(ren, (30 + size[0], 10))
arial_font.set_bold(False)

# Antialiased, transparency, italic
arial_font.set_italic(True)
ren = arial_font.render(text, True, FG)
screen.blit(ren, (30 + size[0], 40 + size[1]))
arial_font.set_italic(False)

courier_italic_bold = pygame.font.SysFont('couriernew', 50, True, True) # bold, italics
# Antialiased, transparency, italic
ren = courier_italic_bold.render(text, True, FG)
screen.blit(ren, (410, 30))

# Antialias, no Antialias
ren = arial_font.render('AntiAliasing=True', True, FG)
screen.blit(ren, (10, 200))

ren = arial_font.render('AntiAliasing=False', False, FG)
screen.blit(ren, (10, 300))

pygame.display.update()

# The game loop
while True:
    for evento in pygame.event.get():
        # pygame.QUIT se genera al cerrar el programa con la X (mouse)
        if evento.type == pygame.QUIT: 
            # Si no se sale bien, el programa puede ocasionar un error
            pygame.quit()
            sys.exit()

