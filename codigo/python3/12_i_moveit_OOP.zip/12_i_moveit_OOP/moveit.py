"""
Este programa muestra 7 ovnis que se mueven por el cielo

Adaptado de:
https://www.pygame.org/docs/tut/MoveIt.html
"""

# Importe las librerías y las constantes
import os, pygame
from pygame.locals import *

ANCHOVENTANA, ALTOVENTANA = 640, 480

# main_dir = os.path.split(os.path.abspath(__file__))[0]
main_dir = '.' 

# Se crean los objetos a mover
class GameObject:
    def __init__(self, image, height, speed):
        self.speed = speed
        self.image = image
        self.pos = image.get_rect().move(0, height)
    def move(self):
        self.pos = self.pos.move(self.speed, 0)
        if self.pos.left > ANCHOVENTANA:
            self.pos.right = 0

# Se carga la imagen en memoria
def load_image(name):
    path = os.path.join(main_dir, 'data', name)
    #return pygame.image.load(path).convert()
    # It is a good idea to convert() all Surfaces before they are blitted many 
    # times. The converted Surface will have no pixel alphas. They will be 
    # stripped if the original had them. Use Surface.convert_alpha() for 
    # preserving or creating per-pixel alphas
    return pygame.image.load(path).convert_alpha()

# El programa principal
def main():
    pygame.init()
    screen = pygame.display.set_mode((ANCHOVENTANA, ALTOVENTANA))

    player = load_image('ufo.png')
    background = load_image('sky.jpg')

    # Se aumenta el tamaño de la imagen de fondo
    #player = pygame.transform.scale(player, (ANCHOVENTANA, ALTOVENTANA))
          
    screen.blit(background, (0, 0))

    objects = []
    for x in range(7):
        objects.append(GameObject(player, x*70, x))

    # El ciclo principal
    while True:
        for event in pygame.event.get():
            if event.type in (QUIT, KEYDOWN):
                pygame.quit()
                return

        # En vez de hacer
        # screen.blit(background, (0, 0))
        # Se hace el siguiente comando
        for obj in objects:
            # blit(source, dest, area=None, special_flags = 0)
            # "area" is Rect object that represents the portion of the source 
            # Surface to draw.
            screen.blit(background, obj.pos, obj.pos)
        # lo que hace dicho comando es únicamente graficar en la pantalla el 
        # pedacito donde estaba la nave, de modo tal que no se tiene que graficar
        # todo sino una parte de la imagen. Esto nos da velocidad en el proceso

        for obj in objects:
            obj.move()
            screen.blit(obj.image, obj.pos)

        pygame.display.update()
        pygame.time.delay(10)

if __name__ == '__main__': 
    main()
